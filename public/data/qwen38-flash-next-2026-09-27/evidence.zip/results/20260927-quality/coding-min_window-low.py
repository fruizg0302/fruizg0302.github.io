def solve(s, t):
    if not t or not s:
        return ""

    from collections import Counter

    need = Counter(t)
    required = len(need)

    formed = 0
    window_counts = {}

    left = 0
    min_len = float('inf')
    min_start = 0

    for right in range(len(s)):
        char = s[right]
        window_counts[char] = window_counts.get(char, 0) + 1

        if char in need and window_counts[char] == need[char]:
            formed += 1

        while formed == required:
            if right - left + 1 < min_len:
                min_len = right - left + 1
                min_start = left

            left_char = s[left]
            window_counts[left_char] -= 1
            if left_char in need and window_counts[left_char] < need[left_char]:
                formed -= 1

            left += 1

    if min_len == float('inf'):
        return ""

    return s[min_start:min_start + min_len]