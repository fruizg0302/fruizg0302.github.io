def solve(text, pattern):
    """
    Full-string wildcard match.
    ? matches exactly one character.
    * matches zero or more characters (including newlines).
    Other characters are literal.
    """
    n = len(text)
    m = len(pattern)
    
    # dp[i][j] = True if text[:i] matches pattern[:j]
    # We can optimize space, but for clarity and correctness with repeated stars,
    # a 2D DP or a greedy approach with backtracking is needed.
    # Given the constraints aren't specified as huge, let's use a standard DP.
    
    # Initialize dp table
    # dp[i][j] means text[0:i] matches pattern[0:j]
    dp = [[False] * (m + 1) for _ in range(n + 1)]
    
    # Empty text matches empty pattern
    dp[0][0] = True
    
    # Empty text can match pattern consisting of only '*'
    for j in range(1, m + 1):
        if pattern[j - 1] == '*':
            dp[0][j] = dp[0][j - 1]
        else:
            break
    
    # Fill the dp table
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if pattern[j - 1] == '*':
                # * matches zero characters: dp[i][j-1]
                # * matches one or more characters: dp[i-1][j]
                dp[i][j] = dp[i][j - 1] or dp[i - 1][j]
            elif pattern[j - 1] == '?':
                # ? matches exactly one character
                dp[i][j] = dp[i - 1][j - 1]
            else:
                # Literal match
                if text[i - 1] == pattern[j - 1]:
                    dp[i][j] = dp[i - 1][j - 1]
                else:
                    dp[i][j] = False
    
    return dp[n][m]