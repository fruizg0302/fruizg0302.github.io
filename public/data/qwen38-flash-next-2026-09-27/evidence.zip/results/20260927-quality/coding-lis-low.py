from bisect import bisect_left

def solve(numbers):
    tails = []
    for num in numbers:
        pos = bisect_left(tails, num)
        if pos == len(tails):
            tails.append(num)
        else:
            tails[pos] = num
    return len(tails)