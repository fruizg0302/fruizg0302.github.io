def solve(text, pattern):
    t = 0
    p = 0
    star_idx = -1
    match = 0

    while t < len(text):
        if p < len(pattern) and (pattern[p] == '?' or pattern[p] == text[t]):
            t += 1
            p += 1
        elif p < len(pattern) and pattern[p] == '*':
            star_idx = p
            match = t
            p += 1
        elif star_idx != -1:
            p = star_idx + 1
            match += 1
            t = match
        else:
            return False

    while p < len(pattern) and pattern[p] == '*':
        p += 1

    return p == len(pattern)