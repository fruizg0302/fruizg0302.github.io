def solve(expression):
    tokens = []
    i = 0
    while i < len(expression):
        ch = expression[i]
        if ch.isspace():
            i += 1
        elif ch in '+-*()':
            tokens.append(ch)
            i += 1
        elif ch.isdigit():
            j = i
            while j < len(expression) and expression[j].isdigit():
                j += 1
            tokens.append(int(expression[i:j]))
            i = j
        else:
            raise ValueError(f"Unexpected character: {ch}")

    pos = [0]

    def peek():
        if pos[0] < len(tokens):
            return tokens[pos[0]]
        return None

    def consume():
        tok = tokens[pos[0]]
        pos[0] += 1
        return tok

    def parse_expr():
        result = parse_term()
        while peek() in ('+', '-'):
            op = consume()
            right = parse_term()
            if op == '+':
                result += right
            else:
                result -= right
        return result

    def parse_term():
        result = parse_factor()
        while peek() == '*':
            consume()
            right = parse_factor()
            result *= right
        return result

    def parse_factor():
        if peek() == '+':
            consume()
            return parse_factor()
        elif peek() == '-':
            consume()
            return -parse_factor()
        else:
            return parse_atom()

    def parse_atom():
        tok = peek()
        if tok == '(':
            consume()
            result = parse_expr()
            if peek() != ')':
                raise ValueError("Expected ')'")
            consume()
            return result
        elif isinstance(tok, int):
            consume()
            return tok
        else:
            raise ValueError(f"Unexpected token: {tok}")

    return parse_expr()