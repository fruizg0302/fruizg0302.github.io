import heapq


def solve(nodes, edges):
    if not nodes:
        return []

    edge_set = set()
    for a, b in edges:
        edge_set.add((a, b))

    adj = {n: [] for n in nodes}
    in_degree = {n: 0 for n in nodes}

    for a, b in edge_set:
        adj[a].append(b)
        in_degree[b] += 1

    heap = [n for n in nodes if in_degree[n] == 0]
    heapq.heapify(heap)

    result = []
    while heap:
        node = heapq.heappop(heap)
        result.append(node)
        for neighbor in adj[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                heapq.heappush(heap, neighbor)

    if len(result) == len(nodes):
        return result
    return None