def solve(expression):
    """
    Evaluate a valid integer expression using +, -, *, parentheses, whitespace and unary +/- (including repeated unary signs).
    Standard precedence, arbitrary-size integers, no division.
    """
    import re
    
    # Tokenize the expression
    # Tokens: numbers, operators (+, -, *), parentheses
    # Whitespace is ignored
    
    tokens = []
    i = 0
    n = len(expression)
    
    while i < n:
        char = expression[i]
        
        if char.isspace():
            i += 1
            continue
        
        if char.isdigit():
            j = i
            while j < n and expression[j].isdigit():
                j += 1
            tokens.append(int(expression[i:j]))
            i = j
            continue
        
        if char in '+-*()':
            tokens.append(char)
            i += 1
            continue
        
        raise ValueError(f"Invalid character: {char}")
    
    # Parser using recursive descent
    # Grammar:
    # expr   -> term (('+' | '-') term)*
    # term   -> factor ('*' factor)*
    # factor -> ('+' | '-') factor | atom
    # atom   -> NUMBER | '(' expr ')'
    
    pos = 0
    
    def peek():
        if pos < len(tokens):
            return tokens[pos]
        return None
    
    def consume():
        nonlocal pos
        token = tokens[pos]
        pos += 1
        return token
    
    def parse_expr():
        result = parse_term()
        while peek() in ['+', '-']:
            op = consume()
            right = parse_term()
            if op == '+':
                result += right
            else:
                result -= right
        return result
    
    def parse_term():
        result = parse_factor()
        while peek() == '*':
            op = consume()
            right = parse_factor()
            result *= right
        return result
    
    def parse_factor():
        token = peek()
        if token == '+':
            consume()
            return parse_factor()
        elif token == '-':
            consume()
            return -parse_factor()
        else:
            return parse_atom()
    
    def parse_atom():
        token = peek()
        if token is None:
            raise ValueError("Unexpected end of expression")
        
        if isinstance(token, int):
            consume()
            return token
        elif token == '(':
            consume()
            result = parse_expr()
            if peek() != ')':
                raise ValueError("Expected closing parenthesis")
            consume()
            return result
        else:
            raise ValueError(f"Unexpected token: {token}")
    
    result = parse_expr()
    
    if pos != len(tokens):
        raise ValueError("Unexpected tokens at end of expression")
    
    return result