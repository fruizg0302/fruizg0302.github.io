def solve(intervals):
    if not intervals:
        return []
    
    # Sort intervals by start, then by end
    sorted_intervals = sorted(intervals, key=lambda x: (x[0], x[1]))
    
    merged = []
    current_start, current_end = sorted_intervals[0]
    
    for i in range(1, len(sorted_intervals)):
        next_start, next_end = sorted_intervals[i]
        
        # If touching or overlapping, merge
        if next_start <= current_end + 1:
            current_end = max(current_end, next_end)
        else:
            merged.append([current_start, current_end])
            current_start, current_end = next_start, next_end
    
    merged.append([current_start, current_end])
    
    return merged