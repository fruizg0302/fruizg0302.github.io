import csv
import io

def solve(text):
    if not text:
        return []
    
    # Use csv.reader with proper settings
    # The csv module handles quoted fields, escaped quotes, commas, and newlines within quotes
    # We need to handle the fact that records use CRLF
    # csv.reader with newline='' handles this correctly
    
    reader = csv.reader(io.StringIO(text, newline=''))
    rows = []
    for row in reader:
        rows.append(row)
    
    return rows