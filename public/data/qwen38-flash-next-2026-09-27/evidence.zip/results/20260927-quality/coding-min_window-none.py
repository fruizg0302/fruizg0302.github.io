def solve(s, t):
    if not t:
        return ""
    
    from collections import Counter
    
    t_count = Counter(t)
    required = len(t_count)
    
    window_counts = {}
    formed = 0
    
    left = 0
    min_len = float('inf')
    min_start = 0
    
    for right in range(len(s)):
        char = s[right]
        if char in t_count:
            window_counts[char] = window_counts.get(char, 0) + 1
            if window_counts[char] == t_count[char]:
                formed += 1
        
        while formed == required:
            current_len = right - left + 1
            if current_len < min_len:
                min_len = current_len
                min_start = left
            
            left_char = s[left]
            if left_char in t_count:
                window_counts[left_char] -= 1
                if window_counts[left_char] < t_count[left_char]:
                    formed -= 1
            left += 1
    
    if min_len == float('inf'):
        return ""
    
    return s[min_start:min_start + min_len]