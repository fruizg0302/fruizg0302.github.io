def solve(expression):
    tokens = []
    i = 0
    n = len(expression)
    while i < n:
        c = expression[i]
        if c.isspace():
            i += 1
        elif c.isdigit():
            j = i
            while j < n and expression[j].isdigit():
                j += 1
            tokens.append(('NUM', int(expression[i:j])))
            i = j
        elif c in '+-':
            tokens.append(('OP', c))
            i += 1
        elif c == '(':
            tokens.append(('LPAREN', '('))
            i += 1
        elif c == ')':
            tokens.append(('RPAREN', ')'))
            i += 1
        else:
            raise ValueError(f"Invalid character: {c}")
    
    pos = 0
    
    def peek():
        if pos < len(tokens):
            return tokens[pos]
        return None
    
    def consume():
        nonlocal pos
        tok = tokens[pos]
        pos += 1
        return tok
    
    def parse_expr():
        left = parse_term()
        while peek() and peek()[0] == 'OP' and peek()[1] in ('+', '-'):
            op = consume()[1]
            right = parse_term()
            if op == '+':
                left = left + right
            else:
                left = left - right
        return left
    
    def parse_term():
        left = parse_factor()
        while peek() and peek()[0] == 'OP' and peek()[1] == '*':
            op = consume()[1]
            right = parse_factor()
            left = left * right
        return left
    
    def parse_factor():
        tok = peek()
        if tok is None:
            raise ValueError("Unexpected end of expression")
        
        if tok[0] == 'OP' and tok[1] in ('+', '-'):
            sign = consume()[1]
            value = parse_factor()
            if sign == '-':
                return -value
            else:
                return value
        elif tok[0] == 'NUM':
            return consume()[1]
        elif tok[0] == 'LPAREN':
            consume()
            value = parse_expr()
            if peek() is None or peek()[0] != 'RPAREN':
                raise ValueError("Missing closing parenthesis")
            consume()
            return value
        else:
            raise ValueError(f"Unexpected token: {tok}")
    
    result = parse_expr()
    if pos != len(tokens):
        raise ValueError("Unexpected tokens at end")
    return result