import csv
import io


def solve(text):
    if not text:
        return []
    reader = csv.reader(io.StringIO(text, newline=''))
    return [row for row in reader]