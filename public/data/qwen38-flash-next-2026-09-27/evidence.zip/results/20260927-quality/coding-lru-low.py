from collections import OrderedDict


def solve(capacity, operations):
    if capacity == 0:
        return [-1 for op in operations if op[0] == "get"]

    cache = OrderedDict()
    results = []

    for op in operations:
        if op[0] == "put":
            key, value = op[1], op[2]
            if key in cache:
                cache[key] = value
                cache.move_to_end(key)
            else:
                if len(cache) >= capacity:
                    cache.popitem(last=False)
                cache[key] = value
        elif op[0] == "get":
            key = op[1]
            if key in cache:
                cache.move_to_end(key)
                results.append(cache[key])
            else:
                results.append(-1)

    return results