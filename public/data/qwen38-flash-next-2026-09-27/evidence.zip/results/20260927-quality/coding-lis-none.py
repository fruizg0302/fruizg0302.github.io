def solve(numbers):
    if not numbers:
        return 0
    
    tails = []
    
    for num in numbers:
        # Binary search for the leftmost element in tails that is >= num
        left, right = 0, len(tails)
        while left < right:
            mid = (left + right) // 2
            if tails[mid] < num:
                left = mid + 1
            else:
                right = mid
        
        if left == len(tails):
            tails.append(num)
        else:
            tails[left] = num
    
    return len(tails)