def solve(events):
    result = {}
    for timestamp, key, value in events:
        if key not in result or timestamp >= result[key][0]:
            result[key] = (timestamp, value)
    return {key: value for key, (timestamp, value) in result.items()}