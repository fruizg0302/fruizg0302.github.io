def solve(nodes, edges):
    if not nodes:
        return []
    
    # Remove duplicate edges
    unique_edges = set()
    for edge in edges:
        unique_edges.add((edge[0], edge[1]))
    
    # Build adjacency list and in-degree count
    adj = {node: [] for node in nodes}
    in_degree = {node: 0 for node in nodes}
    
    for a, b in unique_edges:
        adj[a].append(b)
        in_degree[b] += 1
    
    # Use a min-heap to get lexicographically smallest order
    import heapq
    heap = []
    for node in nodes:
        if in_degree[node] == 0:
            heapq.heappush(heap, node)
    
    result = []
    while heap:
        node = heapq.heappop(heap)
        result.append(node)
        for neighbor in adj[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                heapq.heappush(heap, neighbor)
    
    if len(result) != len(nodes):
        return None
    
    return result