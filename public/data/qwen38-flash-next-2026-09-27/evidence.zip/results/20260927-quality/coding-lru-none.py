def solve(capacity, operations):
    if capacity <= 0:
        return [-1 for op in operations if op[0] == "get"]
    
    from collections import OrderedDict
    
    cache = OrderedDict()
    results = []
    
    for op in operations:
        if op[0] == "put":
            key = op[1]
            value = op[2]
            if key in cache:
                # Update existing key, move to end (most recently used)
                cache[key] = value
                cache.move_to_end(key)
            else:
                # Insert new key
                if len(cache) >= capacity:
                    # Evict least recently used (first item)
                    cache.popitem(last=False)
                cache[key] = value
                cache.move_to_end(key)
        elif op[0] == "get":
            key = op[1]
            if key in cache:
                # Move to end (most recently used)
                cache.move_to_end(key)
                results.append(cache[key])
            else:
                results.append(-1)
    
    return results