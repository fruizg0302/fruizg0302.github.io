def solve(expression):
    tokens = []
    i = 0
    while i < len(expression):
        if expression[i].isspace():
            i += 1
        elif expression[i].isdigit():
            j = i
            while j < len(expression) and expression[j].isdigit():
                j += 1
            tokens.append(int(expression[i:j]))
            i = j
        elif expression[i] in '+-*()':
            tokens.append(expression[i])
            i += 1
        else:
            raise ValueError(f"Unexpected character: {expression[i]}")

    pos = [0]

    def peek():
        if pos[0] < len(tokens):
            return tokens[pos[0]]
        return None

    def consume():
        token = tokens[pos[0]]
        pos[0] += 1
        return token

    def parse_expr():
        result = parse_term()
        while peek() in ('+', '-'):
            op = consume()
            right = parse_term()
            if op == '+':
                result += right
            else:
                result -= right
        return result

    def parse_term():
        result = parse_factor()
        while peek() == '*':
            consume()
            right = parse_factor()
            result *= right
        return result

    def parse_factor():
        if peek() in ('+', '-'):
            op = consume()
            val = parse_factor()
            return val if op == '+' else -val
        return parse_atom()

    def parse_atom():
        if peek() == '(':
            consume()
            result = parse_expr()
            consume()
            return result
        return consume()

    return parse_expr()