import heapq

def solve(nodes, edges):
    if not nodes:
        return []
    
    # Build adjacency list and in-degree count
    # Use sets for neighbors to ignore duplicate edges
    adj = {node: set() for node in nodes}
    in_degree = {node: 0 for node in nodes}
    
    for a, b in edges:
        if b not in adj[a]:
            adj[a].add(b)
            in_degree[b] += 1
            
    # Initialize min-heap with all nodes having in-degree 0
    # This ensures we pick the lexicographically smallest available node
    heap = []
    for node in nodes:
        if in_degree[node] == 0:
            heapq.heappush(heap, node)
            
    result = []
    
    while heap:
        current = heapq.heappop(heap)
        result.append(current)
        
        for neighbor in adj[current]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                heapq.heappush(heap, neighbor)
                
    if len(result) != len(nodes):
        return None
        
    return result